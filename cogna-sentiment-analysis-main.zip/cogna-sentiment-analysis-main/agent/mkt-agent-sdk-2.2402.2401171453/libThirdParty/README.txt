Place third party plug-in files to be processed by the Agent in this directory.
All plug-in files must start with the package name sas.ci360.agent.thirdparty.plugin.